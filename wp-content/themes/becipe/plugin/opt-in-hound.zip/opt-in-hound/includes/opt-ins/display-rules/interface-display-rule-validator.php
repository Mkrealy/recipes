<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

interface OIH_Display_Rule_Validator_Interface {

	public function is_displayable();

}