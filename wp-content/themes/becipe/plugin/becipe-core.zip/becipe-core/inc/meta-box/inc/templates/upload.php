<script id="tmpl-rwmb-upload-area" type="text/html">
	<div class="rwmb-upload-inside">
		<h3>{{{ i18nRwmbMedia.uploadInstructions }}}</h3>
		<p>{{{ i18nRwmbMedia.or }}}</p>
		<button type="button" class="rwmb-browse-button browser button button-hero" id="{{{ _.uniqueId( 'rwmb-upload-browser-') }}}">{{{ i18nRwmbMedia.select }}}</button>
	</div>
</script>
